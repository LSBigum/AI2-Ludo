AI2 - Tools of Artificial Intelligence
====
University of Southern Denmark

LUDO GUI
========
